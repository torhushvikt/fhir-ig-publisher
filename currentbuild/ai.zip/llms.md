# hl7.fhir.no.lab-fhir-ig#0.1.0: Demonstrasjonsguide for laboratorieprøver

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Demonstrasjonsguide for laboratorieprøver](index.md)

### Examples

* [Hemoglobin-1 (Observation)](Observation-Hemoglobin-1.md)
* [Pasient-1 (Patient)](Patient-Pasient-1.md)
