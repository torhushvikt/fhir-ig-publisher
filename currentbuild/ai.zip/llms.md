# hl7.fhir.no.lab-fhir-ig#0.1.0: Demonstrasjonsguide for laboratorieprøver

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Coder fuel demo measurements](CodeSystem-coder-fuel-measurements.md)

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Demonstrasjonsguide for laboratorieprøver](index.md)

### Examples

* [CaffeineForCoder (Observation)](Observation-CaffeineForCoder.md)
* [Hemoglobin-1 (Observation)](Observation-Hemoglobin-1.md)
* [VitaminDForSkier (Observation)](Observation-VitaminDForSkier.md)
* [Ski og Kaffe Demo-lab (Organization)](Organization-DemoLaboratory.md)
* [Pasient-1 (Patient)](Patient-Pasient-1.md)
